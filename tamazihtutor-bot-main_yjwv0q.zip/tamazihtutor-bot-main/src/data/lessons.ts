export interface Lesson {
  id: string;
  title: string;
  description: string;
  level: "Débutant" | "Intermédiaire" | "Avancé";
  duration: string;
  content: string;
}

export const lessons: Lesson[] = [
  {
    id: "basics-1",
    title: "Bases du Tamazight",
    description: "Apprenez les salutations essentielles et les présentations en tamazight",
    level: "Débutant",
    duration: "10 min",
    content: `
# Les salutations en tamazight

Les salutations sont un élément fondamental de toute conversation. Voici quelques expressions essentielles en tamazight:

## Salutations de base

- **Azul** - Bonjour
- **Azul fell-awen** - Bonjour à vous tous
- **Amek telliḍ?** - Comment vas-tu?
- **Labaṣ** - Je vais bien
- **Tanemmirt** - Merci

## Se présenter

- **Isem-iw...** - Je m'appelle...
- **Anwa isem-ik?** (à un homme) - Comment t'appelles-tu?
- **Anwa isem-im?** (à une femme) - Comment t'appelles-tu?

## Prendre congé

- **Ar tufat** - À demain
- **Ar timlilit** - À bientôt
    `
  },
  {
    id: "basics-2",
    title: "Les Nombres",
    description: "Apprenez à compter de 1 à 10 en tamazight",
    level: "Débutant",
    duration: "15 min",
    content: `
# Les nombres en tamazight (1-10)

Les nombres sont essentiels pour le commerce, l'heure, les dates et bien d'autres situations quotidiennes.

## Les nombres de 1 à 10

- **Yan / Yiwen** - Un
- **Sin** - Deux
- **Krad / Tlata** - Trois
- **Kuẓ / Rebɛa** - Quatre
- **Semmus / Xemsa** - Cinq
- **Sḍis / Setta** - Six
- **Sa / Sebɛa** - Sept
- **Tam / Tmenya** - Huit
- **Tẓa / Tesɛa** - Neuf
- **Mraw / Ɛecra** - Dix

Note: Les variantes dépendent des dialectes. La première forme est généralement utilisée dans le Rif et le Moyen Atlas, tandis que la seconde est plus courante dans d'autres régions.
    `
  },
  {
    id: "basics-3",
    title: "Famille et Relations",
    description: "Vocabulaire pour décrire les membres de la famille",
    level: "Débutant",
    duration: "12 min",
    content: `
# La famille en tamazight

Le vocabulaire de la famille est important pour décrire vos relations personnelles et parler de vos proches.

## Termes familiaux courants

- **Baba / Dada** - Père
- **Yemma / Imma** - Mère
- **Gma** - Mon frère
- **Wetma** - Ma sœur
- **Jeddi** - Grand-père
- **Jida / Nanna** - Grand-mère
- **Xali** - Oncle maternel
- **Xalti** - Tante maternelle
- **Ɛemmi** - Oncle paternel
- **Ɛemti** - Tante paternelle
- **Arraw / Tarwa** - Enfants
- **Tawacult** - Famille

Ces termes peuvent varier selon les régions et les dialectes.
    `
  },
  {
    id: "grammar-1",
    title: "Structure de Base",
    description: "Introduction à la structure des phrases en tamazight",
    level: "Débutant",
    duration: "20 min",
    content: `
# Structure de base en tamazight

Le tamazight a une structure de phrase qui peut différer du français. Comprendre cette structure est essentiel pour formuler des phrases correctes.

## Ordre des mots

L'ordre de base des mots en tamazight est généralement **Verbe-Sujet-Objet (VSO)**, contrairement au français qui utilise Sujet-Verbe-Objet (SVO).

Exemple:
- Français: **Je mange une pomme** (Sujet-Verbe-Objet)
- Tamazight: **Cciɣ tatefaht** (Verbe-Objet)

Dans cet exemple, le sujet "je" est intégré dans la conjugaison du verbe "cciɣ" (je mange).

## Pronoms personnels

Les pronoms personnels en tamazight peuvent être indépendants ou attachés:

- **Nekk** - Je/Moi
- **Kecc** - Tu/Toi (masculin)
- **Kemm** - Tu/Toi (féminin)
- **Netta** - Il/Lui
- **Nettat** - Elle
- **Nekni** - Nous
- **Kenwi** - Vous (masculin)
- **Kenmti** - Vous (féminin)
- **Nitni** - Ils/Eux
- **Nitenti** - Elles

Comme vous pouvez le voir, le tamazight distingue le genre non seulement à la troisième personne, mais aussi à la deuxième personne.
    `
  },
  {
    id: "grammar-2",
    title: "Les Verbes",
    description: "Introduction aux verbes et à la conjugaison simple",
    level: "Intermédiaire",
    duration: "25 min",
    content: `
# Les verbes en tamazight

Les verbes sont essentiels pour exprimer des actions et des états. Voici une introduction à la conjugaison des verbes en tamazight.

## Le verbe "être" - "ili"

Le verbe "être" est fondamental:

- **Nekk lliɣ** - Je suis
- **Kecc telliḍ** - Tu es (masculin)
- **Kemm telliḍ** - Tu es (féminin)
- **Netta yella** - Il est
- **Nettat tella** - Elle est
- **Nekni nella** - Nous sommes
- **Kenwi tellam** - Vous êtes (masculin)
- **Kenmti tellamt** - Vous êtes (féminin)
- **Nitni llan** - Ils sont
- **Nitenti llant** - Elles sont

## Temps des verbes

En tamazight, il existe principalement trois temps:

1. **L'accompli (passé)** - pour des actions terminées
2. **L'inaccompli (présent et futur)** - pour des actions en cours ou à venir
3. **L'aoriste (impératif et subjonctif)** - pour des ordres ou des souhaits

Exemple avec le verbe "cc" (manger):

**Accompli (passé)**:
- **Cciɣ** - J'ai mangé
- **Tecciḍ** - Tu as mangé
- **Yecca** - Il a mangé
- **Tecca** - Elle a mangé

**Inaccompli (présent)**:
- **Ttettaɣ** - Je mange/Je suis en train de manger
- **Ttettaḍ** - Tu manges
- **Itetta** - Il mange
- **Ttetta** - Elle mange
    `
  }
];
