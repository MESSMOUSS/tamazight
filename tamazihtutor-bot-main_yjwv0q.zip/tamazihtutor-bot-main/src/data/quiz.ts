export interface Quiz {
  id: string;
  lessonId: string;
  questions: QuizQuestion[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  choices: {
    id: string;
    text: string;
  }[];
  correctAnswerId: string;
  explanation: string;
}

export const quizzes: Quiz[] = [
  {
    id: "quiz-basics-1",
    lessonId: "basics-1",
    questions: [
      {
        id: "q1",
        question: "Comment dit-on 'Bonjour' en tamazight?",
        choices: [
          { id: "a", text: "Azul" },
          { id: "b", text: "Tanemmirt" },
          { id: "c", text: "Labaṣ" },
          { id: "d", text: "Ar tufat" }
        ],
        correctAnswerId: "a",
        explanation: "La salutation 'Bonjour' se traduit par 'Azul' en tamazight. C'est l'une des expressions les plus courantes pour saluer quelqu'un."
      },
      {
        id: "q2",
        question: "Comment demande-t-on 'Comment vas-tu?' en tamazight?",
        choices: [
          { id: "a", text: "Anwa isem-ik?" },
          { id: "b", text: "Ar tufat" },
          { id: "c", text: "Amek telliḍ?" },
          { id: "d", text: "Tanemmirt" }
        ],
        correctAnswerId: "c",
        explanation: "'Amek telliḍ?' est la façon de demander 'Comment vas-tu?' en tamazight. C'est une question courante après avoir salué quelqu'un."
      },
      {
        id: "q3",
        question: "Que signifie 'Tanemmirt' en français?",
        choices: [
          { id: "a", text: "Bonjour" },
          { id: "b", text: "Comment ça va?" },
          { id: "c", text: "Au revoir" },
          { id: "d", text: "Merci" }
        ],
        correctAnswerId: "d",
        explanation: "'Tanemmirt' signifie 'Merci' en français. C'est une expression de gratitude dans la langue tamazight."
      }
    ]
  },
  {
    id: "quiz-basics-2",
    lessonId: "basics-2",
    questions: [
      {
        id: "q1",
        question: "Comment dit-on 'Deux' en tamazight?",
        choices: [
          { id: "a", text: "Yan" },
          { id: "b", text: "Sin" },
          { id: "c", text: "Krad" },
          { id: "d", text: "Mraw" }
        ],
        correctAnswerId: "b",
        explanation: "Le nombre 'Deux' se dit 'Sin' en tamazight."
      },
      {
        id: "q2",
        question: "Quel est le mot pour 'Cinq' en tamazight?",
        choices: [
          { id: "a", text: "Kuẓ" },
          { id: "b", text: "Sḍis" },
          { id: "c", text: "Semmus" },
          { id: "d", text: "Sa" }
        ],
        correctAnswerId: "c",
        explanation: "Le nombre 'Cinq' se dit 'Semmus' ou 'Xemsa' selon les dialectes en tamazight."
      },
      {
        id: "q3",
        question: "Comment dit-on 'Dix' en tamazight?",
        choices: [
          { id: "a", text: "Tẓa" },
          { id: "b", text: "Tam" },
          { id: "c", text: "Sa" },
          { id: "d", text: "Mraw" }
        ],
        correctAnswerId: "d",
        explanation: "Le nombre 'Dix' se dit 'Mraw' ou 'Ɛecra' selon les dialectes en tamazight."
      }
    ]
  },
  {
    id: "quiz-expressions-1",
    lessonId: "expressions-1",
    questions: [
      {
        id: "q1",
        question: "Comment dit-on 'Au revoir' en tamazight?",
        choices: [
          { id: "a", text: "Ar tufat" },
          { id: "b", text: "Azul" },
          { id: "c", text: "Tanemmirt" },
          { id: "d", text: "Tufawin" }
        ],
        correctAnswerId: "a",
        explanation: "'Ar tufat' signifie 'Au revoir' ou plus précisément 'À demain' en tamazight."
      },
      {
        id: "q2",
        question: "Quelle est la bonne réponse à 'Amek telliḍ?'",
        choices: [
          { id: "a", text: "Azul" },
          { id: "b", text: "Labaṣ" },
          { id: "c", text: "Tanemmirt" },
          { id: "d", text: "Ar tufat" }
        ],
        correctAnswerId: "b",
        explanation: "'Labaṣ' (ça va bien) est la réponse appropriée à 'Amek telliḍ?' (Comment vas-tu?)."
      },
      {
        id: "q3",
        question: "Comment dit-on 'Bonne journée' en tamazight?",
        choices: [
          { id: "a", text: "Ass ameggaz" },
          { id: "b", text: "Azul" },
          { id: "c", text: "Iḍ ameggaz" },
          { id: "d", text: "Ar tufat" }
        ],
        correctAnswerId: "a",
        explanation: "'Ass ameggaz' signifie 'Bonne journée' en tamazight. 'Ass' signifie 'jour' et 'ameggaz' signifie 'bon'."
      }
    ]
  },
  {
    id: "quiz-family-1",
    lessonId: "family-1",
    questions: [
      {
        id: "q1",
        question: "Comment dit-on 'père' en tamazight?",
        choices: [
          { id: "a", text: "Yemma" },
          { id: "b", text: "Baba" },
          { id: "c", text: "Gma" },
          { id: "d", text: "Weltma" }
        ],
        correctAnswerId: "b",
        explanation: "'Baba' signifie 'père' en tamazight."
      },
      {
        id: "q2",
        question: "Quel est le mot pour 'mère' en tamazight?",
        choices: [
          { id: "a", text: "Yemma" },
          { id: "b", text: "Baba" },
          { id: "c", text: "Dadda" },
          { id: "d", text: "Tawacult" }
        ],
        correctAnswerId: "a",
        explanation: "'Yemma' signifie 'mère' en tamazight."
      },
      {
        id: "q3",
        question: "Comment dit-on 'frère' en tamazight?",
        choices: [
          { id: "a", text: "Weltma" },
          { id: "b", text: "Xali" },
          { id: "c", text: "Gma" },
          { id: "d", text: "Dadda" }
        ],
        correctAnswerId: "c",
        explanation: "'Gma' signifie 'frère' en tamazight."
      }
    ]
  },
  {
    id: "quiz-food-1",
    lessonId: "food-1",
    questions: [
      {
        id: "q1",
        question: "Comment dit-on 'pain' en tamazight?",
        choices: [
          { id: "a", text: "Aman" },
          { id: "b", text: "Aɣrum" },
          { id: "c", text: "Seksu" },
          { id: "d", text: "Tayazit" }
        ],
        correctAnswerId: "b",
        explanation: "'Aɣrum' signifie 'pain' en tamazight."
      },
      {
        id: "q2",
        question: "Quel est le mot pour 'eau' en tamazight?",
        choices: [
          { id: "a", text: "Aman" },
          { id: "b", text: "Aḍil" },
          { id: "c", text: "Ayefki" },
          { id: "d", text: "Isufar" }
        ],
        correctAnswerId: "a",
        explanation: "'Aman' signifie 'eau' en tamazight."
      },
      {
        id: "q3",
        question: "Comment dit-on 'viande' en tamazight?",
        choices: [
          { id: "a", text: "Aɣrum" },
          { id: "b", text: "Aman" },
          { id: "c", text: "Aksum" },
          { id: "d", text: "Zeitun" }
        ],
        correctAnswerId: "c",
        explanation: "'Aksum' signifie 'viande' en tamazight."
      }
    ]
  }
];
