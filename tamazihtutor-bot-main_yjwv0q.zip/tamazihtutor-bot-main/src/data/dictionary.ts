export interface DictionaryEntry {
  id: string;
  tamazightWord: string;
  latinTranscription: string;
  frenchTranslation: string;
  englishTranslation?: string;
  pronunciation: string;
  example: {
    tamazight: string;
    french: string;
  };
  category: "noun" | "verb" | "adjective" | "expression" | "other";
}

// Helper function to generate IDs
const generateId = (index: number): string => {
  return (index + 1).toString().padStart(3, '0');
};

// Function to get available starting letters for the alphabet index
export const getAvailableLetters = (): string[] => {
  const letters = new Set<string>();
  
  dictionaryEntries.forEach(entry => {
    if (entry.latinTranscription && entry.latinTranscription.length > 0) {
      letters.add(entry.latinTranscription.charAt(0).toLowerCase());
    }
  });
  
  return Array.from(letters).sort();
};

// Create a more efficient data structure with letter indexing
export const dictionaryEntries: DictionaryEntry[] = [
  // Existing entries
  {
    id: generateId(0),
    tamazightWord: "ⴰⵣⵓⵍ",
    latinTranscription: "azul",
    frenchTranslation: "bonjour",
    englishTranslation: "hello",
    pronunciation: "a-zoul",
    example: {
      tamazight: "Azul! Amek telliḍ?",
      french: "Bonjour! Comment vas-tu?"
    },
    category: "expression"
  },
  {
    id: generateId(1),
    tamazightWord: "ⵜⴰⵏⴻⵎⵎⵉⵔⵜ",
    latinTranscription: "tanemmirt",
    frenchTranslation: "merci",
    englishTranslation: "thank you",
    pronunciation: "ta-nem-mirt",
    example: {
      tamazight: "Tanemmirt i uţikki-inek.",
      french: "Merci pour ton aide."
    },
    category: "expression"
  },
  {
    id: generateId(2),
    tamazightWord: "ⴰⵎⴻⴽ ⵜⴻⵍⵍⵉⴹ",
    latinTranscription: "amek telliḍ",
    frenchTranslation: "comment vas-tu",
    pronunciation: "a-mek tel-lidh",
    example: {
      tamazight: "Azul, amek telliḍ ass-a?",
      french: "Bonjour, comment vas-tu aujourd'hui?"
    },
    category: "expression"
  },
  {
    id: generateId(3),
    tamazightWord: "ⵍⴰⴱⴰⵙ",
    latinTranscription: "labaṣ",
    frenchTranslation: "bien / ça va bien",
    pronunciation: "la-bass",
    example: {
      tamazight: "Labaṣ, tanemmirt!",
      french: "Je vais bien, merci!"
    },
    category: "expression"
  },
  {
    id: generateId(4),
    tamazightWord: "ⴰⵔ ⵜⵓⴼⴰⵜ",
    latinTranscription: "ar tufat",
    frenchTranslation: "à demain",
    pronunciation: "ar tou-fat",
    example: {
      tamazight: "Ar tufat a amdakkel-inu!",
      french: "À demain mon ami!"
    },
    category: "expression"
  },
  {
    id: generateId(5),
    tamazightWord: "ⴰⵙⵙ",
    latinTranscription: "ass",
    frenchTranslation: "jour",
    pronunciation: "ass",
    example: {
      tamazight: "Ass ameggaz!",
      french: "Bonne journée!"
    },
    category: "noun"
  },
  {
    id: generateId(6),
    tamazightWord: "ⴰⵎⴰⵏ",
    latinTranscription: "aman",
    frenchTranslation: "eau",
    pronunciation: "a-man",
    example: {
      tamazight: "Tella tedgirt deg aman.",
      french: "Il y a du poisson dans l'eau."
    },
    category: "noun"
  },
  {
    id: generateId(7),
    tamazightWord: "ⴰⵖⵔⵓⵎ",
    latinTranscription: "aɣrum",
    frenchTranslation: "pain",
    pronunciation: "ar-roum",
    example: {
      tamazight: "Cciɣ aɣrum d zzit.",
      french: "J'ai mangé du pain avec de l'huile."
    },
    category: "noun"
  },
  {
    id: generateId(8),
    tamazightWord: "ⵜⴰⵎⴰⵣⵉⵖⵜ",
    latinTranscription: "tamaziɣt",
    frenchTranslation: "langue berbère/tamazight",
    pronunciation: "ta-ma-zirht",
    example: {
      tamazight: "Ssneɣ tamaziɣt cwiṭ.",
      french: "Je connais un peu de tamazight."
    },
    category: "noun"
  },
  {
    id: generateId(9),
    tamazightWord: "ⵉⵙⴻⵎ",
    latinTranscription: "isem",
    frenchTranslation: "nom",
    pronunciation: "i-sem",
    example: {
      tamazight: "Anwa isem-ik?",
      french: "Quel est ton nom?"
    },
    category: "noun"
  },
  {
    id: generateId(10),
    tamazightWord: "ⵜⵜⵓ",
    latinTranscription: "ttu",
    frenchTranslation: "oublier",
    pronunciation: "ttou",
    example: {
      tamazight: "Ttuɣ isem-is.",
      french: "J'ai oublié son nom."
    },
    category: "verb"
  },
  {
    id: generateId(11),
    tamazightWord: "ⵙⵙⵉⵏ",
    latinTranscription: "ssin",
    frenchTranslation: "savoir / connaître",
    pronunciation: "s-sin",
    example: {
      tamazight: "Ssineɣ ad ɣreɣ tamaziɣt.",
      french: "Je sais lire le tamazight."
    },
    category: "verb"
  },
  {
    id: generateId(12),
    tamazightWord: "ⴰⴼⵓⵙ",
    latinTranscription: "afus",
    frenchTranslation: "main",
    englishTranslation: "hand",
    pronunciation: "a-fous",
    example: {
      tamazight: "Ssird ifassen-inek.",
      french: "Lave tes mains."
    },
    category: "noun"
  },
  {
    id: generateId(13),
    tamazightWord: "ⵜⴰⵡⵡⵓⵔⵜ",
    latinTranscription: "tawwurt",
    frenchTranslation: "porte",
    englishTranslation: "door",
    pronunciation: "ta-wourt",
    example: {
      tamazight: "Mdel tawwurt, ttxil-k.",
      french: "Ferme la porte, s'il te plaît."
    },
    category: "noun"
  },
  {
    id: generateId(14),
    tamazightWord: "ⵉⵥⵔⵉ",
    latinTranscription: "iẓri",
    frenchTranslation: "voir",
    englishTranslation: "to see",
    pronunciation: "iz-ri",
    example: {
      tamazight: "Ur t-ẓriɣ ara.",
      french: "Je ne le vois pas."
    },
    category: "verb"
  },
  {
    id: generateId(15),
    tamazightWord: "ⵜⵉⴳⵎⵎⵉ",
    latinTranscription: "tigmmi",
    frenchTranslation: "maison",
    englishTranslation: "house",
    pronunciation: "tig-mi",
    example: {
      tamazight: "Tigmmi-nneɣ tameqqrant.",
      french: "Notre maison est grande."
    },
    category: "noun"
  },
  {
    id: generateId(16),
    tamazightWord: "ⵜⴰⵎⴻⵟⵟⵓⵜ",
    latinTranscription: "tameṭṭut",
    frenchTranslation: "femme",
    englishTranslation: "woman",
    pronunciation: "ta-me-ttout",
    example: {
      tamazight: "Tameṭṭut-a d tamenzut.",
      french: "Cette femme est sage."
    },
    category: "noun"
  },
  {
    id: generateId(17),
    tamazightWord: "ⴰⵔⴳⴰⵣ",
    latinTranscription: "argaz",
    frenchTranslation: "homme",
    englishTranslation: "man",
    pronunciation: "ar-gaz",
    example: {
      tamazight: "Argaz-a d amɣar.",
      french: "Cet homme est vieux."
    },
    category: "noun"
  },
  {
    id: generateId(18),
    tamazightWord: "ⵜⴰⴼⵓⴽⵜ",
    latinTranscription: "tafukt",
    frenchTranslation: "soleil",
    englishTranslation: "sun",
    pronunciation: "ta-foukt",
    example: {
      tamazight: "Tafukt teɣli.",
      french: "Le soleil s'est couché."
    },
    category: "noun"
  },
  {
    id: generateId(19),
    tamazightWord: "ⵉⵟⵟⵉⵊ",
    latinTranscription: "iṭṭij",
    frenchTranslation: "soleil",
    englishTranslation: "sun",
    pronunciation: "i-ttij",
    example: {
      tamazight: "Iṭṭij iḥma ass-a.",
      french: "Le soleil est chaud aujourd'hui."
    },
    category: "noun"
  },
  {
    id: generateId(20),
    tamazightWord: "ⴰⵢⵓⵔ",
    latinTranscription: "ayur",
    frenchTranslation: "lune / mois",
    englishTranslation: "moon / month",
    pronunciation: "a-your",
    example: {
      tamazight: "Ayur yettfeǧǧiǧ deg igenni.",
      french: "La lune brille dans le ciel."
    },
    category: "noun"
  },
  {
    id: generateId(21),
    tamazightWord: "ⵉⵜⵔⵉ",
    latinTranscription: "itri",
    frenchTranslation: "étoile",
    englishTranslation: "star",
    pronunciation: "i-tri",
    example: {
      tamazight: "Itran ttfeǧǧiǧen deg yiḍ.",
      french: "Les étoiles brillent dans la nuit."
    },
    category: "noun"
  },
  {
    id: generateId(22),
    tamazightWord: "ⴰⵙⴻⴼⵔⵓ",
    latinTranscription: "asefru",
    frenchTranslation: "poème",
    englishTranslation: "poem",
    pronunciation: "a-se-frou",
    example: {
      tamazight: "Yura asefru yelhan.",
      french: "Il a écrit un beau poème."
    },
    category: "noun"
  },
  {
    id: generateId(23),
    tamazightWord: "ⵜⵉⵎⵍⵉⵍⵉⵜ",
    latinTranscription: "timlilit",
    frenchTranslation: "rencontre",
    englishTranslation: "meeting",
    pronunciation: "tim-li-lit",
    example: {
      tamazight: "Timlilit-nneɣ tameqqrant azekka.",
      french: "Notre grande réunion est demain."
    },
    category: "noun"
  },
  {
    id: generateId(24),
    tamazightWord: "ⵙⵉⵡⴻⵍ",
    latinTranscription: "siwel",
    frenchTranslation: "parler / appeler",
    englishTranslation: "to speak / to call",
    pronunciation: "si-wel",
    example: {
      tamazight: "Siwel-as azekka.",
      french: "Appelle-le demain."
    },
    category: "verb"
  },
  
  // New entries - Adding more words alphabetically
  {
    id: generateId(25),
    tamazightWord: "ⴰⴱⴰⵍⵉⵖ",
    latinTranscription: "abaliɣ",
    frenchTranslation: "adulte",
    englishTranslation: "adult",
    pronunciation: "a-ba-ligh",
    example: {
      tamazight: "Yuɣal d abaliɣ.",
      french: "Il est devenu adulte."
    },
    category: "noun"
  },
  {
    id: generateId(26),
    tamazightWord: "ⴰⴱⴻⵔⴽⴰⵏ",
    latinTranscription: "aberkan",
    frenchTranslation: "noir",
    englishTranslation: "black",
    pronunciation: "a-ber-kan",
    example: {
      tamazight: "Yesɛa acekkuḥ aberkan.",
      french: "Il a des cheveux noirs."
    },
    category: "adjective"
  },
  {
    id: generateId(27),
    tamazightWord: "ⴰⴱⵉⴹ",
    latinTranscription: "abiḍ",
    frenchTranslation: "nuit",
    englishTranslation: "night",
    pronunciation: "a-bidh",
    example: {
      tamazight: "Abiḍ yezga d asemmaḍ.",
      french: "La nuit est toujours froide."
    },
    category: "noun"
  },
  {
    id: generateId(28),
    tamazightWord: "ⴰⴱⵔⵉⴷ",
    latinTranscription: "abrid",
    frenchTranslation: "chemin, route",
    englishTranslation: "road, path",
    pronunciation: "a-brid",
    example: {
      tamazight: "Abrid-a yewɛer.",
      french: "Ce chemin est difficile."
    },
    category: "noun"
  },
  {
    id: generateId(29),
    tamazightWord: "ⴰⴱⵔⵓⵛ",
    latinTranscription: "abruc",
    frenchTranslation: "garçon",
    englishTranslation: "boy",
    pronunciation: "a-brouch",
    example: {
      tamazight: "Abruc-nni yecḍeḥ.",
      french: "Le garçon a dansé."
    },
    category: "noun"
  },
  {
    id: generateId(30),
    tamazightWord: "ⴰⴱⵓⴹ",
    latinTranscription: "abuḍ",
    frenchTranslation: "ventre",
    englishTranslation: "belly",
    pronunciation: "a-boudh",
    example: {
      tamazight: "Yeccat alamma yečča abuḍ-is.",
      french: "Il a mangé jusqu'à remplir son ventre."
    },
    category: "noun"
  },
  {
    id: generateId(31),
    tamazightWord: "ⴰⴷⴰⵔ",
    latinTranscription: "adar",
    frenchTranslation: "pied",
    englishTranslation: "foot",
    pronunciation: "a-dar",
    example: {
      tamazight: "Adar-is yeɣli.",
      french: "Son pied est tombé."
    },
    category: "noun"
  },
  {
    id: generateId(32),
    tamazightWord: "ⴰⴷⴼⴻⵍ",
    latinTranscription: "adfel",
    frenchTranslation: "neige",
    englishTranslation: "snow",
    pronunciation: "ad-fel",
    example: {
      tamazight: "Adfel yeɣli-d tameddit-nni.",
      french: "La neige est tombée ce soir-là."
    },
    category: "noun"
  },
  {
    id: generateId(33),
    tamazightWord: "ⴰⴷⵍⵉⵙ",
    latinTranscription: "adlis",
    frenchTranslation: "livre",
    englishTranslation: "book",
    pronunciation: "ad-lis",
    example: {
      tamazight: "Ɣriɣ adlis yelhan.",
      french: "J'ai lu un bon livre."
    },
    category: "noun"
  },
  {
    id: generateId(34),
    tamazightWord: "ⴰⴷⵔⴰⵔ",
    latinTranscription: "adrar",
    frenchTranslation: "montagne",
    englishTranslation: "mountain",
    pronunciation: "ad-rar",
    example: {
      tamazight: "Adrar-nni yeɛlay aṭas.",
      french: "Cette montagne est très haute."
    },
    category: "noun"
  },
  {
    id: generateId(35),
    tamazightWord: "ⴰⴹⴰⵔ",
    latinTranscription: "aḍar",
    frenchTranslation: "pied",
    englishTranslation: "foot",
    pronunciation: "a-dhar",
    example: {
      tamazight: "Yerḍel-iyi aḍar-is.",
      french: "Il m'a prêté son pied."
    },
    category: "noun"
  },
  {
    id: generateId(36),
    tamazightWord: "ⴰⴼⴰⵔⵉⵙ",
    latinTranscription: "afaris",
    frenchTranslation: "poirier",
    englishTranslation: "pear tree",
    pronunciation: "a-fa-ris",
    example: {
      tamazight: "Afaris-nneɣ d ameqqran.",
      french: "Notre poirier est grand."
    },
    category: "noun"
  },
  {
    id: generateId(37),
    tamazightWord: "ⴰⴼⴻⵍⵍⴰⵃ",
    latinTranscription: "afellaḥ",
    frenchTranslation: "agriculteur",
    englishTranslation: "farmer",
    pronunciation: "a-fel-lah",
    example: {
      tamazight: "Baba d afellaḥ.",
      french: "Mon père est agriculteur."
    },
    category: "noun"
  },
  {
    id: generateId(38),
    tamazightWord: "ⴰⴼⵓⵙ",
    latinTranscription: "afus",
    frenchTranslation: "main",
    englishTranslation: "hand",
    pronunciation: "a-fus",
    example: {
      tamazight: "Afus-iw yeɣli-d fell-as.",
      french: "Ma main est tombée sur lui."
    },
    category: "noun"
  },
  {
    id: generateId(39),
    tamazightWord: "ⴰⴳⴻⴹⵉⴹ",
    latinTranscription: "ageḍiḍ",
    frenchTranslation: "oiseau",
    englishTranslation: "bird",
    pronunciation: "a-ge-dhidh",
    example: {
      tamazight: "Ageḍiḍ-nni yeffeɣ-d seg ubuḍ.",
      french: "L'oiseau est sorti du nid."
    },
    category: "noun"
  },
  {
    id: generateId(40),
    tamazightWord: "ⴰⴳⴻⵍⵣⵉⵎ",
    latinTranscription: "agelzim",
    frenchTranslation: "pioche",
    englishTranslation: "pickaxe",
    pronunciation: "a-gel-zim",
    example: {
      tamazight: "Yewwi-d agelzim.",
      french: "Il a apporté une pioche."
    },
    category: "noun"
  },
  // Expanded dictionary entries
  {
    id: generateId(41),
    tamazightWord: "ⴰⴳⵉⵔⵉⵡ",
    latinTranscription: "agiriw",
    frenchTranslation: "épaule",
    englishTranslation: "shoulder",
    pronunciation: "a-gi-riw",
    example: {
      tamazight: "Agiriw-iw yeqqers.",
      french: "Mon épaule me fait mal."
    },
    category: "noun"
  },
  {
    id: generateId(42),
    tamazightWord: "ⴰⴳⵍⴰⵙ",
    latinTranscription: "aglas",
    frenchTranslation: "ceinture",
    englishTranslation: "belt",
    pronunciation: "a-glas",
    example: {
      tamazight: "Err-d aglas-inek!",
      french: "Mets ta ceinture!"
    },
    category: "noun"
  },
  {
    id: generateId(43),
    tamazightWord: "ⴰⵖⴻⵔⴸⴰ",
    latinTranscription: "aɣerda",
    frenchTranslation: "souris",
    englishTranslation: "mouse",
    pronunciation: "a-gher-da",
    example: {
      tamazight: "Aɣerda yezzeli.",
      french: "La souris court."
    },
    category: "noun"
  },
  {
    id: generateId(44),
    tamazightWord: "ⴰⵖⴻⵔⵎⴰⵎ",
    latinTranscription: "aɣermam",
    frenchTranslation: "gris",
    englishTranslation: "gray",
    pronunciation: "a-gher-mam",
    example: {
      tamazight: "Yesɛa ini aɣermam.",
      french: "Il est de couleur grise."
    },
    category: "adjective"
  },
  {
    id: generateId(45),
    tamazightWord: "ⴰⵖⵉⵍⴰⵙ",
    latinTranscription: "aɣilas",
    frenchTranslation: "lion",
    englishTranslation: "lion",
    pronunciation: "a-ghi-las",
    example: {
      tamazight: "Aɣilas d agellid n lwuhuc.",
      french: "Le lion est le roi des animaux."
    },
    category: "noun"
  },
  {
    id: generateId(46),
    tamazightWord: "ⴰⵖⵔⵓⵎ",
    latinTranscription: "aɣrum",
    frenchTranslation: "pain",
    englishTranslation: "bread",
    pronunciation: "a-ghroum",
    example: {
      tamazight: "Aɣrum-a azedgan.",
      french: "Ce pain est frais."
    },
    category: "noun"
  },
  {
    id: generateId(47),
    tamazightWord: "ⴰⵀⵉⵍ",
    latinTranscription: "ahil",
    frenchTranslation: "programme",
    englishTranslation: "program",
    pronunciation: "a-hil",
    example: {
      tamazight: "Ahil n wass-a yeččur.",
      french: "Le programme d'aujourd'hui est chargé."
    },
    category: "noun"
  },
  {
    id: generateId(48),
    tamazightWord: "ⴰⵊⴻⵏⵡⵉ",
    latinTranscription: "ajenwi",
    frenchTranslation: "couteau",
    englishTranslation: "knife",
    pronunciation: "a-jen-wi",
    example: {
      tamazight: "Ajenwi-a yefret.",
      french: "Ce couteau est tranchant."
    },
    category: "noun"
  },
  {
    id: generateId(49),
    tamazightWord: "ⴰⴽⴰⵍ",
    latinTranscription: "akal",
    frenchTranslation: "terre, sol",
    englishTranslation: "earth, soil",
    pronunciation: "a-kal",
    example: {
      tamazight: "Akal n tmurt-iw d azegzaw.",
      french: "La terre de mon pays est fertile."
    },
    category: "noun"
  },
  {
    id: generateId(50),
    tamazightWord: "ⴰⴽⵙⵓⵎ",
    latinTranscription: "aksum",
    frenchTranslation: "viande",
    englishTranslation: "meat",
    pronunciation: "ak-soum",
    example: {
      tamazight: "Aksum n izimer yelha.",
      french: "La viande d'agneau est bonne."
    },
    category: "noun"
  },
  {
    id: generateId(51),
    tamazightWord: "ⴰⴽⵡⴼⴰⵢ",
    latinTranscription: "akwfay",
    frenchTranslation: "lait",
    englishTranslation: "milk",
    pronunciation: "ak-wfay",
    example: {
      tamazight: "Akwfay n tfunast yelha i tezmert.",
      french: "Le lait de vache est bon pour la santé."
    },
    category: "noun"
  },
  {
    id: generateId(52),
    tamazightWord: "ⴰⵍⴻⵖⵎ",
    latinTranscription: "aleɣm",
    frenchTranslation: "chameau",
    englishTranslation: "camel",
    pronunciation: "a-leghm",
    example: {
      tamazight: "Aleɣm yezmer ad idder war aman.",
      french: "Le chameau peut vivre sans eau."
    },
    category: "noun"
  },
  {
    id: generateId(53),
    tamazightWord: "ⴰⵎⴰⴹⴰⵍ",
    latinTranscription: "amaḍal",
    frenchTranslation: "monde",
    englishTranslation: "world",
    pronunciation: "a-ma-dhal",
    example: {
      tamazight: "Amaḍal d ameqqran.",
      french: "Le monde est grand."
    },
    category: "noun"
  },
  {
    id: generateId(54),
    tamazightWord: "ⴰⵎⴰⵔⵉⵔ",
    latinTranscription: "amarir",
    frenchTranslation: "sourire",
    englishTranslation: "smile",
    pronunciation: "a-ma-rir",
    example: {
      tamazight: "Amarir-is iqewwi-yi.",
      french: "Son sourire me donne de la force."
    },
    category: "noun"
  },
  {
    id: generateId(55),
    tamazightWord: "ⴰⵎⴱⵓⵍⴰⵏⵙ",
    latinTranscription: "ambulans",
    frenchTranslation: "ambulance",
    englishTranslation: "ambulance",
    pronunciation: "am-bou-lans",
    example: {
      tamazight: "Ambulans tusa-d.",
      french: "L'ambulance est arrivée."
    },
    category: "noun"
  },
  {
    id: generateId(56),
    tamazightWord: "ⴰⵎⴷⴰⴽⴽⵓⵍ",
    latinTranscription: "amdakkul",
    frenchTranslation: "ami",
    englishTranslation: "friend",
    pronunciation: "am-dak-koul",
    example: {
      tamazight: "Amdakkul-iw yefka-yi afus.",
      french: "Mon ami m'a aidé."
    },
    category: "noun"
  },
  {
    id: generateId(57),
    tamazightWord: "ⴰⵎⴷⴰⴽⴽⵯⴻⵍ",
    latinTranscription: "amdakkʷel",
    frenchTranslation: "ami",
    englishTranslation: "friend",
    pronunciation: "am-dak-wel",
    example: {
      tamazight: "Amdakkʷel-iw yusa-d iḍelli.",
      french: "Mon ami est venu hier."
    },
    category: "noun"
  },
  {
    id: generateId(58),
    tamazightWord: "ⴰⵎⴷⴷⴰⴽⵓⵍ",
    latinTranscription: "amddakul",
    frenchTranslation: "ami",
    englishTranslation: "friend",
    pronunciation: "am-dda-koul",
    example: {
      tamazight: "Amddakul-iw d amaynu.",
      french: "C'est mon nouvel ami."
    },
    category: "noun"
  },
  {
    id: generateId(59),
    tamazightWord: "ⴰⵎⴻⴽⵙⴰ",
    latinTranscription: "ameksa",
    frenchTranslation: "berger",
    englishTranslation: "shepherd",
    pronunciation: "a-mek-sa",
    example: {
      tamazight: "Ameksa yessa ulli-s.",
      french: "Le berger garde ses moutons."
    },
    category: "noun"
  },
  {
    id: generateId(60),
    tamazightWord: "ⴰⵎⴻⵍⵖⵉⵖ",
    latinTranscription: "amelɣiɣ",
    frenchTranslation: "crâne",
    englishTranslation: "skull",
    pronunciation: "a-mel-ghigh",
    example: {
      tamazight: "Amelɣiɣ-is yejreḥ.",
      french: "Son crâne est blessé."
    },
    category: "noun"
  },
  {
    id: generateId(61),
    tamazightWord: "ⴰⵎⴻⵏⵏⵓⵖ",
    latinTranscription: "amennuɣ",
    frenchTranslation: "combat",
    englishTranslation: "fight",
    pronunciation: "a-men-nough",
    example: {
      tamazight: "Amennuɣ yekker.",
      french: "Un combat a éclaté."
    },
    category: "noun"
  },
  {
    id: generateId(62),
    tamazightWord: "ⴰⵎⴻⵔⵡⴰⵙ",
    latinTranscription: "amerwas",
    frenchTranslation: "emprunt",
    englishTranslation: "loan",
    pronunciation: "a-mer-was",
    example: {
      tamazight: "Yewwi amerwas.",
      french: "Il a pris un emprunt."
    },
    category: "noun"
  },
  {
    id: generateId(63),
    tamazightWord: "ⴰⵎⴻⵙⵙⴰⵙ",
    latinTranscription: "amessas",
    frenchTranslation: "fade",
    englishTranslation: "bland",
    pronunciation: "a-mes-sas",
    example: {
      tamazight: "Učči-a d amessas.",
      french: "Ce plat est fade."
    },
    category: "adjective"
  },
  {
    id: generateId(64),
    tamazightWord: "ⴰⵎⴻⵟⵟⵓ",
    latinTranscription: "ameṭṭu",
    frenchTranslation: "larme",
    englishTranslation: "tear",
    pronunciation: "a-met-tou",
    example: {
      tamazight: "Ameṭṭu-s yeɣli-d.",
      french: "Sa larme est tombée."
    },
    category: "noun"
  },
  {
    id: generateId(65),
    tamazightWord: "ⴰⵎⴻⵥⵥⵓⵖ",
    latinTranscription: "ameẓẓuɣ",
    frenchTranslation: "oreille",
    englishTranslation: "ear",
    pronunciation: "a-mez-zough",
    example: {
      tamazight: "Ameẓẓuɣ-iw yeqqur.",
      french: "Mon oreille est sèche."
    },
    category: "noun"
  },
  {
    id: generateId(66),
    tamazightWord: "ⴰⵎⵖⴰⵔ",
    latinTranscription: "amɣar",
    frenchTranslation: "vieux",
    englishTranslation: "old man",
    pronunciation: "am-ghar",
    example: {
      tamazight: "Amɣar-nni yella da.",
      french: "Le vieux était ici."
    },
    category: "noun"
  },
  {
    id: generateId(67),
    tamazightWord: "ⴰⵎⵇⵇⵔⴰⵏ",
    latinTranscription: "ameqqran",
    frenchTranslation: "grand",
    englishTranslation: "big",
    pronunciation: "a-meq-qran",
    example: {
      tamazight: "Axxam-nneɣ d ameqqran.",
      french: "Notre maison est grande."
    },
    category: "adjective"
  },
  {
    id: generateId(68),
    tamazightWord: "ⴰⵎⵇⵇⵯⵔⴰⵏ",
    latinTranscription: "ameqqʷran",
    frenchTranslation: "grand",
    englishTranslation: "big",
    pronunciation: "a-meq-qwran",
    example: {
      tamazight: "Baba-s d ameqqʷran deg taddart.",
      french: "Son père est important dans le village."
    },
    category: "adjective"
  },
  {
    id: generateId(69),
    tamazightWord: "ⴰⵎⵣⵡⴰⵔⵓ",
    latinTranscription: "amzwaru",
    frenchTranslation: "premier",
    englishTranslation: "first",
    pronunciation: "am-zwa-rou",
    example: {
      tamazight: "Nekk d amzwaru deg tneɣrit.",
      french: "Je suis premier de la classe."
    },
    category: "adjective"
  },
  {
    id: generateId(70),
    tamazightWord: "ⴰⵎⵥⴰⴹ",
    latinTranscription: "amẓad",
    frenchTranslation: "gourmand",
    englishTranslation: "greedy",
    pronunciation: "am-zadh",
    example: {
      tamazight: "Mmi-s d amẓad.",
      french: "Son fils est gourmand."
    },
    category: "adjective"
  },
  
  // Continuing with more entries
  {
    id: generateId(71),
    tamazightWord: "ⴰⵏⴰⴱⴰⴹ",
    latinTranscription: "anabaḍ",
    frenchTranslation: "gouvernement",
    englishTranslation: "government",
    pronunciation: "a-na-badh",
    example: {
      tamazight: "Anabaḍ amaynu yettussbedd.",
      french: "Un nouveau gouvernement a été formé."
    },
    category: "noun"
  },
  {
    id: generateId(72),
    tamazightWord: "ⴰⵏⴰⴼⴰⴳ",
    latinTranscription: "anafag",
    frenchTranslation: "avion",
    englishTranslation: "airplane",
    pronunciation: "a-na-fag",
    example: {
      tamazight: "Anafag yeffeɣ-d tafrara.",
      french: "L'avion est parti tôt le matin."
    },
    category: "noun"
  },
  {
    id: generateId(73),
    tamazightWord: "ⴰⵏⴰⵔⵓⵣ",
    latinTranscription: "anaruz",
    frenchTranslation: "espoir",
    englishTranslation: "hope",
    pronunciation: "a-na-rouz",
    example: {
      tamazight: "Anaruz n tudert d azref n yal amdan.",
      french: "L'espoir de vie est le droit de chaque personne."
    },
    category: "noun"
  },
  {
    id: generateId(74),
    tamazightWord: "ⴰⵏⴻⴱⴳⵉ",
    latinTranscription: "anebgi",
    frenchTranslation: "invité",
    englishTranslation: "guest",
    pronunciation: "a-neb-gui",
    example: {
      tamazight: "Anebgi-nneɣ yusa-d iḍelli.",
      french: "Notre invité est arrivé hier."
    },
    category: "noun"
  },
  {
    id: generateId(75),
    tamazightWord: "ⴰⵏⴻⴱⴷⵓ",
    latinTranscription: "anebdu",
    frenchTranslation: "été",
    englishTranslation: "summer",
    pronunciation: "a-neb-dou",
    example: {
      tamazight: "Deg unebdu, ttemɣin tiyni.",
      french: "En été, les dattes mûrissent."
    },
    category: "noun"
  },
  {
    id: generateId(76),
    tamazightWord: "ⴰⵏⴻⵇⵇⴰⴱ",
    latinTranscription: "aneqqab",
    frenchTranslation: "trou",
    englishTranslation: "hole",
    pronunciation: "a-neq-qab",
    example: {
      tamazight: "Aneqqab-nni yeǧǧa-t yiṭij.",
      french: "Ce trou a été laissé par le soleil."
    },
    category: "noun"
  },
  {
    id: generateId(77),
    tamazightWord: "ⴰⵏⴻⴳⴳⴰⵔⵓ",
    latinTranscription: "aneggaru",
    frenchTranslation: "dernier",
    englishTranslation: "last",
    pronunciation: "a-neg-ga-rou",
    example: {
      tamazight: "Aneggaru ad yeǧǧ alɣem am wins amezwaru.",
      french: "Le dernier laissera le chameau comme le premier."
    },
    category: "adjective"
  },
  {
    id: generateId(78),
    tamazightWord: "ⴰⵏⴻⵃⵍⴰⴼⵓ",
    latinTranscription: "aneḥlafu",
    frenchTranslation: "sanglier",
    englishTranslation: "wild boar",
    pronunciation: "a-neh-la-fou",
    example: {
      tamazight: "Aneḥlafu yezdeɣ deg tẓegwa.",
      french: "Le sanglier vit dans les forêts."
    },
    category: "noun"
  },
  {
    id: generateId(79),
    tamazightWord: "ⴰⵏⵉⵔⵉ",
    latinTranscription: "aniri",
    frenchTranslation: "front",
    englishTranslation: "forehead",
    pronunciation: "a-ni-ri",
    example: {
      tamazight: "Aniri-ines yuli-t lḥamu.",
      french: "Son front est chaud."
    },
    category: "noun"
  },
  {
    id: generateId(80),
    tamazightWord: "ⴰⵏⵍⴻⵎ",
    latinTranscription: "anlem",
    frenchTranslation: "dromadaire",
    englishTranslation: "dromedary",
    pronunciation: "an-lem",
    example: {
      tamazight: "Anlem irennu aman.",
      french: "Le dromadaire stocke de l'eau."
    },
    category: "noun"
  },
  {
    id: generateId(81),
    tamazightWord: "ⴰⵏⵙⴰⵢ",
    latinTranscription: "ansay",
    frenchTranslation: "tradition",
    englishTranslation: "tradition",
    pronunciation: "an-say",
    example: {
      tamazight: "Ansay-nneɣ d aqdim.",
      french: "Notre tradition est ancienne."
    },
    category: "noun"
  },
  {
    id: generateId(82),
    tamazightWord: "ⴰⵏⵥⴰⴹ",
    latinTranscription: "anẓaḍ",
    frenchTranslation: "cheveu",
    englishTranslation: "hair",
    pronunciation: "an-zadh",
    example: {
      tamazight: "Anẓaḍ-ines d aberkan.",
      french: "Ses cheveux sont noirs."
    },
    category: "noun"
  },
  {
    id: generateId(83),
    tamazightWord: "ⴰⵏⵡⴰⵍ",
    latinTranscription: "anwal",
    frenchTranslation: "cuisine",
    englishTranslation: "kitchen",
    pronunciation: "an-wal",
    example: {
      tamazight: "Anwal-nneɣ d ameqqran.",
      french: "Notre cuisine est grande."
    },
    category: "noun"
  },
  {
    id: generateId(84),
    tamazightWord: "ⴰⵇⴰⴱⴰⵛ",
    latinTranscription: "aqabac",
    frenchTranslation: "chapeau",
    englishTranslation: "hat",
    pronunciation: "a-qa-bach",
    example: {
      tamazight: "Aqabac-ines d azegzaw.",
      french: "Son chapeau est vert."
    },
    category: "noun"
  },
  {
    id: generateId(85),
    tamazightWord: "ⴰⵇⴰⴷⵓⵎ",
    latinTranscription: "aqadum",
    frenchTranslation: "visage",
    englishTranslation: "face",
    pronunciation: "a-qa-doum",
    example: {
      tamazight: "Aqadum-is d azedgan.",
      french: "Son visage est propre."
    },
    category: "noun"
  },
  {
    id: generateId(86),
    tamazightWord: "ⴰⵇⴻⵕⵕⵓ",
    latinTranscription: "aqeṛṛu",
    frenchTranslation: "tête",
    englishTranslation: "head",
    pronunciation: "a-qer-rou",
    example: {
      tamazight: "Aqeṛṛu-ines yeẓẓay.",
      french: "Sa tête est lourde."
    },
    category: "noun"
  },
  {
    id: generateId(87),
    tamazightWord: "ⴰⵇⴰⵎⵓⵎ",
    latinTranscription: "aqamum",
    frenchTranslation: "bouche",
    englishTranslation: "mouth",
    pronunciation: "a-qa-moum",
    example: {
      tamazight: "Aqamum-is irekkem.",
      french: "Sa bouche est pourrie."
    },
    category: "noun"
  },
  {
    id: generateId(88),
    tamazightWord: "ⴰⵇⴱⴰⵢⵍⵉ",
    latinTranscription: "aqbayli",
    frenchTranslation: "kabyle",
    englishTranslation: "kabyle",
    pronunciation: "aq-bay-li",
    example: {
      tamazight: "Aqbayli yettmeslay s teqbaylit.",
      french: "Le kabyle parle le kabyle."
    },
    category: "noun"
  },
  {
    id: generateId(89),
    tamazightWord: "ⴰⵇⴻⵛⵡⴰⵍ",
    latinTranscription: "aqecwal",
    frenchTranslation: "panier",
    englishTranslation: "basket",
    pronunciation: "a-qech-wal",
    example: {
      tamazight: "Aqecwal-a yeččur d tizegzawin.",
      french: "Ce panier est plein de légumes verts."
    },
    category: "noun"
  },
  {
    id: generateId(90),
    tamazightWord: "ⴰⵇⴻⴷⴷⴰⵛ",
    latinTranscription: "aqeddac",
    frenchTranslation: "serviteur",
    englishTranslation: "servant",
    pronunciation: "a-qed-dach",
    example: {
      tamazight: "Aqeddac d win ixeddmen i wiyiḍ.",
      french: "Le serviteur est celui qui sert les autres."
    },
    category: "noun"
  },
  {
    id: generateId(91),
    tamazightWord: "ⴰⵇⴻⵏⴷⵓⵔ",
    latinTranscription: "aqendur",
    frenchTranslation: "robe",
    englishTranslation: "dress",
    pronunciation: "a-qen-dour",
    example: {
      tamazight: "Aqendur-a yettwaxdem s ufus.",
      french: "Cette robe est faite à la main."
    },
    category: "noun"
  },
  {
    id: generateId(92),
    tamazightWord: "ⴰⵇⴻⵔⵔⵓ",
    latinTranscription: "aqerru",
    frenchTranslation: "tête",
    englishTranslation: "head",
    pronunciation: "a-qer-rou",
    example: {
      tamazight: "Aqerru n bnadem d azal-is.",
      french: "La tête de l'homme est sa valeur."
    },
    category: "noun"
  },
  {
    id: generateId(93),
    tamazightWord: "ⴰⵇⴼⴰⵍ",
    latinTranscription: "aqfal",
    frenchTranslation: "serrure",
    englishTranslation: "lock",
    pronunciation: "aq-fal",
    example: {
      tamazight: "Aqfal n tewwurt yerrez.",
      french: "La serrure de la porte est cassée."
    },
    category: "noun"
  },
  {
    id: generateId(94),
    tamazightWord: "ⴰⵇⵊⵓⵏ",
    latinTranscription: "aqjun",
    frenchTranslation: "chien",
    englishTranslation: "dog",
    pronunciation: "aq-jun",
    example: {
      tamazight: "Aqjun-nneɣ yettɛessa axxam.",
      french: "Notre chien garde la maison."
    },
    category: "noun"
  },
  {
    id: generateId(95),
    tamazightWord: "ⴰⵇⵍⴰⵍ",
    latinTranscription: "aqlal",
    frenchTranslation: "poterie",
    englishTranslation: "pottery",
    pronunciation: "aq-lal",
    example: {
      tamazight: "Aqlal-a yettwaxdem s wakal.",
      french: "Cette poterie est faite avec de l'argile."
    },
    category: "noun"
  },
  {
    id: generateId(96),
    tamazightWord: "ⴰⵇⵓⵔⴰⵔ",
    latinTranscription: "aqurar",
    frenchTranslation: "sac",
    englishTranslation: "bag",
    pronunciation: "a-qou-rar",
    example: {
      tamazight: "Aqurar-ines yeččur d idrimen.",
      french: "Son sac est plein d'argent."
    },
    category: "noun"
  },
  {
    id: generateId(97),
    tamazightWord: "ⴰⵇⵡⴰⵎ",
    latinTranscription: "aqwam",
    frenchTranslation: "structure",
    englishTranslation: "structure",
    pronunciation: "aq-wam",
    example: {
      tamazight: "Aqwam n yixxamen yemxalaf.",
      french: "La structure des maisons est différente."
    },
    category: "noun"
  },
  {
    id: generateId(98),
    tamazightWord: "ⴰⵔⴰⵔ",
    latinTranscription: "arar",
    frenchTranslation: "jeu",
    englishTranslation: "game",
    pronunciation: "a-rar",
    example: {
      tamazight: "Arar-a yessefreh igerdan.",
      french: "Ce jeu rend les enfants heureux."
    },
    category: "noun"
  },
  {
    id: generateId(99),
    tamazightWord: "ⴰⵔⴰⵡ",
    latinTranscription: "araw",
    frenchTranslation: "enfant",
    englishTranslation: "child",
    pronunciation: "a-raw",
    example: {
      tamazight: "Araw-is yezdeɣ di temdint.",
      french: "Son enfant vit en ville."
    },
    category: "noun"
  },
  {
    id: generateId(100),
    tamazightWord: "ⴰⵔⴱⵉⴱ",
    latinTranscription: "arbib",
    frenchTranslation: "beau-fils",
    englishTranslation: "stepson",
    pronunciation: "ar-bib",
    example: {
      tamazight: "Arbib-is yeffeɣ ɣer uɣerbaz.",
      french: "Son beau-fils est allé à l'école."
    },
    category: "noun"
  },
  
  // Additional entries continue with verbs, expressions, adjectives
  {
    id: generateId(101),
    tamazightWord: "ⴰⵔⴷⴰⵢⵏⴰ",
    latinTranscription: "ardayna",
    frenchTranslation: "orange (fruit)",
    englishTranslation: "orange (fruit)",
    pronunciation: "ar-day-na",
    example: {
      tamazight: "Ardayna-a tezga tezdag.",
      french: "Cette orange est toujours fraîche."
    },
    category: "noun"
  },
  {
    id: generateId(102),
    tamazightWord: "ⴰⵔⴳⴰⵣ",
    latinTranscription: "argaz",
    frenchTranslation: "homme",
    englishTranslation: "man",
    pronunciation: "ar-gaz",
    example: {
      tamazight: "Argaz n tidet ur ittekkes awal-is.",
      french: "Un homme véritable ne reprend pas sa parole."
    },
    category: "noun"
  },
  {
    id: generateId(103),
    tamazightWord: "ⴰⵔⵉⴼ",
    latinTranscription: "arif",
    frenchTranslation: "rif",
    englishTranslation: "rif",
    pronunciation: "a-rif",
    example: {
      tamazight: "Arif d tamnatt deg ugafa n Merruk.",
      french: "Le Rif est une région au nord du Maroc."
    },
    category: "noun"
  },
  {
    id: generateId(104),
    tamazightWord: "ⴰⵔⵙⴻⵍ",
    latinTranscription: "arsel",
    frenchTranslation: "champignon",
    englishTranslation: "mushroom",
    pronunciation: "ar-sel",
    example: {
      tamazight: "Arsel-a yezdeg i wučči.",
      french: "Ce champignon est comestible."
    },
    category: "noun"
  },
  {
    id: generateId(105),
    tamazightWord: "ⴰⵔⵜⴰⵏ",
    latinTranscription: "artan",
    frenchTranslation: "fil",
    englishTranslation: "thread",
    pronunciation: "ar-tan",
    example: {
      tamazight: "Artan-a ad ifernen timelsa-inek.",
      french: "Ce fil va réparer tes vêtements."
    },
    category: "noun"
  },
  {
    id: generateId(106),
    tamazightWord: "ⴰⵔⵓⵙ",
    latinTranscription: "arus",
    frenchTranslation: "prêter",
    englishTranslation: "to lend",
    pronunciation: "a-rous",
    example: {
      tamazight: "Arus-iyi-d adlis-nni azegzaw.",
      french: "Prête-moi ce livre vert."
    },
    category: "verb"
  },
  {
    id: generateId(107),
    tamazightWord: "ⴰⵙⴰⴷⵓ",
    latinTranscription: "asadu",
    frenchTranslation: "vent",
    englishTranslation: "wind",
    pronunciation: "a-sa-dou",
    example: {
      tamazight: "Asadu yeffeɣ-d seg umalu.",
      french: "Le vent est venu de l'ouest."
    },
    category: "noun"
  },
  {
    id: generateId(108),
    tamazightWord: "ⴰⵙⴰⴼⴰⵔ",
    latinTranscription: "asafar",
    frenchTranslation: "médicament",
    englishTranslation: "medicine",
    pronunciation: "a-sa-far",
    example: {
      tamazight: "Asafar-a inefɛen i yilfan.",
      french: "Ce médicament est utile pour les maladies."
    },
    category: "noun"
  },
  {
    id: generateId(109),
    tamazightWord: "ⴰⵙⴰⴼⵓ",
    latinTranscription: "asafu",
    frenchTranslation: "flamme",
    englishTranslation: "flame",
    pronunciation: "a-sa-fou",
    example: {
      tamazight: "Asafu-nni yekker-d seg ukufay.",
      french: "La flamme est sortie du foyer."
    },
    category: "noun"
  },
  {
    id: generateId(110),
    tamazightWord: "ⴰⵙⴰⴽⴰ",
    latinTranscription: "asaka",
    frenchTranslation: "gué",
    englishTranslation: "ford",
    pronunciation: "a-sa-ka",
    example: {
      tamazight: "Asaka-nni yezger asif.",
      french: "Ce gué traverse la rivière."
    },
    category: "noun"
  }
];
