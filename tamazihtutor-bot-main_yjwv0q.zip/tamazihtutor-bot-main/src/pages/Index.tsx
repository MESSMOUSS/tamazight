import React, { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import LessonCard from "@/components/LessonCard";
import QuizCard from "@/components/QuizCard";
import ConversationSimulator from "@/components/ConversationSimulator";
import TranslationTool from "@/components/TranslationTool";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Book, Check, MessageSquare, BookOpen, ArrowRight, Languages } from "lucide-react";
import { lessons } from "@/data/lessons";
import { quizzes } from "@/data/quiz";
import { dictionaryEntries } from "@/data/dictionary";
const Index = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<string>("home");
  const [activeLesson, setActiveLesson] = useState<string | null>(null);
  const [activeQuiz, setActiveQuiz] = useState<string | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash && ['home', 'learn', 'practice', 'dictionary', 'conversation', 'translation', 'quiz', 'lesson-content'].includes(hash)) {
        if (hash === 'dictionary') {
          navigate('/dictionary');
        } else {
          setActiveSection(hash);
        }
      }
    };
    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, [navigate]);
  const navigateToSection = (section: string) => {
    if (section === "dictionary") {
      navigate('/dictionary');
    } else {
      setActiveSection(section);
      window.location.hash = section;
    }
  };
  const handleLessonClick = (lessonId: string) => {
    setActiveLesson(lessonId);
    navigateToSection("lesson-content");
  };
  const handleStartQuiz = (lessonId: string) => {
    const quiz = quizzes.find(q => q.lessonId === lessonId);
    if (quiz) {
      setActiveQuiz(quiz.id);
      setCurrentQuestionIndex(0);
      setQuizScore(0);
      navigateToSection("quiz");
    } else {
      console.error(`No quiz found for lesson: ${lessonId}`);
    }
  };
  const handleQuizCompletion = (isCorrect: boolean) => {
    if (isCorrect) {
      setQuizScore(prevScore => prevScore + 1);
    }
    if (!activeQuiz) return;
    const quiz = quizzes.find(q => q.id === activeQuiz);
    if (!quiz) return;
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(prevIndex => prevIndex + 1);
    } else {
      navigateToSection("quiz-result");
    }
  };
  const currentLesson = lessons.find(lesson => lesson.id === activeLesson);
  const currentQuiz = quizzes.find(quiz => quiz.id === activeQuiz);
  const currentQuestion = currentQuiz?.questions[currentQuestionIndex];
  return <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-grow">
        {activeSection === "home" && <div id="home" className="relative overflow-hidden">
            {/* Hero section */}
            <div className="container mx-auto px-4 py-16 md:py-24">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div className="text-left">
                  <h1 className="text-4xl font-bold text-tamazight-blue mb-4 text-center md:text-5xl">
                    Apprenez le Tamazight Facilement
                  </h1>
                  <p className="text-lg text-gray-700 mb-8">
                    Découvrez la langue berbère grâce à des cours interactifs, des exercices
                    pratiques et un assistant IA personnalisé.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Button size="lg" className="bg-tamazight-blue hover:bg-tamazight-green" onClick={() => navigateToSection("learn")}>
                      Commencer l'apprentissage
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="lg" onClick={() => navigateToSection("conversation")}>
                      Pratiquer la conversation
                    </Button>
                  </div>
                </div>
                <div className="relative">
                  <div className="w-full h-80 bg-gradient-to-r from-tamazight-blue to-tamazight-green rounded-lg overflow-hidden flex items-center justify-center">
                    <div className="berber-pattern absolute inset-0"></div>
                    <div className="relative z-10 p-8 text-white text-center">
                      <h2 className="text-3xl font-bold mb-4">ⵜⴰⵎⴰⵣⵉⵖⵜ</h2>
                      <p className="text-xl">Tamaziɣt</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Features section */}
            <div className="bg-gray-50 py-16">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12 text-tamazight-blue">
                  Comment apprendre avec TamazightTutor
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                  <Card className="border-t-4 border-t-tamazight-blue">
                    <CardHeader>
                      <div className="w-12 h-12 bg-tamazight-blue rounded-full flex items-center justify-center mb-4">
                        <BookOpen className="h-6 w-6 text-white" />
                      </div>
                      <CardTitle>Leçons Interactives</CardTitle>
                      <CardDescription>
                        Apprenez les bases du tamazight avec des leçons structurées et progressives.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button variant="link" className="text-tamazight-blue p-0" onClick={() => navigateToSection("learn")}>
                        Découvrir les leçons
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="border-t-4 border-t-tamazight-orange">
                    <CardHeader>
                      <div className="w-12 h-12 bg-tamazight-orange rounded-full flex items-center justify-center mb-4">
                        <Check className="h-6 w-6 text-white" />
                      </div>
                      <CardTitle>Exercices Pratiques</CardTitle>
                      <CardDescription>
                        Renforcez vos connaissances avec des quiz et des exercices interactifs.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button variant="link" className="text-tamazight-orange p-0" onClick={() => navigateToSection("practice")}>
                        Faire des exercices
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="border-t-4 border-t-tamazight-green">
                    <CardHeader>
                      <div className="w-12 h-12 bg-tamazight-green rounded-full flex items-center justify-center mb-4">
                        <MessageSquare className="h-6 w-6 text-white" />
                      </div>
                      <CardTitle>Conversation IA</CardTitle>
                      <CardDescription>
                        Pratiquez votre tamazight avec notre assistant de conversation intelligent.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button variant="link" className="text-tamazight-green p-0" onClick={() => navigateToSection("conversation")}>
                        Commencer à converser
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="border-t-4 border-t-tamazight-yellow">
                    <CardHeader>
                      <div className="w-12 h-12 bg-tamazight-yellow rounded-full flex items-center justify-center mb-4">
                        <Languages className="h-6 w-6 text-white" />
                      </div>
                      <CardTitle>Traduction</CardTitle>
                      <CardDescription>
                        Traduisez des mots et phrases entre le tamazight, le français et l'anglais.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button variant="link" onClick={() => navigateToSection("translation")} className="text-tamazight-yellow p-0 py-[46px]">
                        Utiliser le traducteur
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>}

        {activeSection === "learn" && <div id="learn" className="container mx-auto px-4 py-12">
            <h2 className="text-3xl font-bold mb-8 text-tamazight-blue">Leçons de Tamazight</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {lessons.map(lesson => <LessonCard key={lesson.id} title={lesson.title} description={lesson.description} level={lesson.level} duration={lesson.duration} onClick={() => handleLessonClick(lesson.id)} />)}
            </div>
          </div>}

        {activeSection === "lesson-content" && currentLesson && <div className="container mx-auto px-4 py-12">
            <Button variant="ghost" onClick={() => setActiveSection("learn")} className="mb-4">
              ← Retour aux leçons
            </Button>
            
            <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
              <h2 className="text-3xl font-bold mb-2 text-tamazight-blue">{currentLesson.title}</h2>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <span className="text-sm bg-tamazight-blue/10 text-tamazight-blue px-3 py-1 rounded-full">
                    {currentLesson.level}
                  </span>
                  <span className="text-sm text-gray-500">
                    Durée: {currentLesson.duration}
                  </span>
                </div>
              </div>
              
              <div className="prose max-w-none" dangerouslySetInnerHTML={{
            __html: currentLesson.content.replace(/\n/g, '<br>').replace(/# (.*)/g, '<h1>$1</h1>').replace(/## (.*)/g, '<h2>$1</h2>').replace(/- \*\*(.*)\*\* - (.*)/g, '<div class="flex items-baseline mb-2"><span class="font-bold mr-2">$1:</span><span>$2</span></div>')
          }} />
              
              <div className="mt-8 flex justify-end">
                <Button onClick={() => handleStartQuiz(currentLesson.id)} className="bg-tamazight-green hover:bg-tamazight-blue text-white">
                  Tester vos connaissances
                </Button>
              </div>
            </div>
          </div>}

        {activeSection === "quiz" && currentQuestion && <div className="container mx-auto px-4 py-12">
            <Button variant="ghost" onClick={() => activeLesson ? handleLessonClick(activeLesson) : setActiveSection("learn")} className="mb-4">
              ← Retour à la leçon
            </Button>
            
            <div className="mb-4 text-center">
              <h2 className="text-2xl font-bold text-tamazight-blue mb-2">Quiz</h2>
              <p className="text-gray-600">
                Question {currentQuestionIndex + 1} sur {currentQuiz?.questions.length}
              </p>
            </div>
            
            <QuizCard question={currentQuestion.question} choices={currentQuestion.choices} correctAnswerId={currentQuestion.correctAnswerId} explanation={currentQuestion.explanation} onComplete={handleQuizCompletion} />
          </div>}

        {activeSection === "quiz-result" && currentQuiz && <div className="container mx-auto px-4 py-12">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="text-xl text-center">Résultats du Quiz</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-6">
                  <p className="text-3xl font-bold">
                    {quizScore} / {currentQuiz.questions.length}
                  </p>
                  <p className="text-muted-foreground">
                    {quizScore === currentQuiz.questions.length ? "Parfait ! Vous avez tout réussi !" : quizScore > currentQuiz.questions.length / 2 ? "Bien joué ! Continuez comme ça !" : "Continuez à pratiquer pour progresser !"}
                  </p>
                </div>
                <div className="flex flex-col space-y-3">
                  <Button onClick={() => setActiveSection("learn")}>
                    Retour aux leçons
                  </Button>
                  <Button variant="outline" onClick={() => {
                setCurrentQuestionIndex(0);
                setQuizScore(0);
                setActiveSection("quiz");
              }}>
                    Recommencer le quiz
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>}

        {activeSection === "practice" && <div id="practice" className="container mx-auto px-4 py-12">
            <h2 className="text-3xl font-bold mb-8 text-tamazight-blue">Exercices de pratique</h2>
            
            <Tabs defaultValue="quiz" className="mx-auto max-w-3xl">
              <TabsList className="w-full grid grid-cols-2 mb-8">
                <TabsTrigger value="quiz">Quiz</TabsTrigger>
                <TabsTrigger value="writing">Écriture (Bientôt)</TabsTrigger>
              </TabsList>
              <TabsContent value="quiz" className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {quizzes.map(quiz => {
                const relatedLesson = lessons.find(l => l.id === quiz.lessonId);
                return <Card key={quiz.id}>
                        <CardHeader>
                          <CardTitle className="text-lg">
                            Quiz: {relatedLesson?.title || "Tamazight"}
                          </CardTitle>
                          <CardDescription>
                            {quiz.questions.length} questions
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <Button onClick={() => {
                      setActiveQuiz(quiz.id);
                      setCurrentQuestionIndex(0);
                      setQuizScore(0);
                      navigateToSection("quiz");
                    }} className="w-full bg-tamazight-orange hover:bg-tamazight-yellow">
                            Démarrer
                          </Button>
                        </CardContent>
                      </Card>;
              })}
                </div>
              </TabsContent>
              <TabsContent value="writing">
                <div className="text-center py-12">
                  <p className="text-lg text-gray-600 mb-4">
                    Des exercices d'écriture seront bientôt disponibles !
                  </p>
                  <p className="text-gray-500">
                    Revenez vérifier dans quelques jours.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </div>}

        {activeSection === "conversation" && <div id="conversation" className="container mx-auto px-4 py-12">
            <h2 className="text-3xl font-bold mb-8 text-tamazight-blue">
              Conversation en Tamazight
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto mb-8 text-center">
              Pratiquez vos compétences en tamazight en conversant avec notre assistant. 
              Vous pouvez écrire en tamazight ou en français, et l'assistant vous aidera à apprendre.
            </p>
            
            <ConversationSimulator />
          </div>}

        {activeSection === "translation" && <div id="translation" className="container mx-auto px-4 py-12">
            <h2 className="text-3xl font-bold mb-8 text-tamazight-blue">
              Outil de Traduction
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto mb-8 text-center">
              Traduisez des mots et des phrases entre le tamazight, le français et l'anglais.
              Cet outil utilise notre dictionnaire intégré pour fournir des traductions précises.
            </p>
            
            <TranslationTool />
          </div>}
      </main>

      <Footer />
    </div>;
};
export default Index;
