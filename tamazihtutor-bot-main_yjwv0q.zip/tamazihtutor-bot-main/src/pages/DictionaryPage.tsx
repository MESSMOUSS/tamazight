import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import DictionaryEntry from "@/components/DictionaryEntry";
import { dictionaryEntries, getAvailableLetters } from "@/data/dictionary";

const DictionaryPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);
  const [alphabetIndex, setAlphabetIndex] = useState<string[]>([]);
  const [filteredEntries, setFilteredEntries] = useState(dictionaryEntries);

  useEffect(() => {
    // Get all available first letters when component mounts
    setAlphabetIndex(getAvailableLetters());
  }, []);

  useEffect(() => {
    let filtered = dictionaryEntries;
    
    if (searchTerm) {
      filtered = filtered.filter(
        (entry) =>
          entry.tamazightWord.toLowerCase().includes(searchTerm.toLowerCase()) ||
          entry.latinTranscription.toLowerCase().includes(searchTerm.toLowerCase()) ||
          entry.frenchTranslation.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (entry.englishTranslation && entry.englishTranslation.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    if (selectedLetter) {
      filtered = filtered.filter(
        (entry) => entry.latinTranscription.toLowerCase().startsWith(selectedLetter.toLowerCase())
      );
    }
    
    setFilteredEntries(filtered);
  }, [searchTerm, selectedLetter]);

  return (
    <div className="container mx-auto px-4 py-12">
      <h2 className="text-3xl font-bold mb-8 text-tamazight-blue">
        Dictionnaire Tamazight-Français-Anglais
      </h2>
      
      <div className="max-w-2xl mx-auto mb-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Rechercher un mot en tamazight, français ou anglais..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setSelectedLetter(null); // Reset letter selection when searching
            }}
          />
        </div>
      </div>
      
      {/* Alphabetical index */}
      <div className="max-w-2xl mx-auto mb-6 flex flex-wrap gap-1 justify-center">
        {selectedLetter && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSelectedLetter(null)}
            className="mb-2"
          >
            Tous
          </Button>
        )}
        {alphabetIndex.map(letter => (
          <Button
            key={letter}
            variant={selectedLetter === letter ? "default" : "outline"}
            size="sm"
            onClick={() => {
              setSelectedLetter(letter === selectedLetter ? null : letter);
              setSearchTerm(''); // Clear search when selecting a letter
            }}
            className="min-w-8"
          >
            {letter.toUpperCase()}
          </Button>
        ))}
      </div>
      
      <div className="max-w-2xl mx-auto">
        {filteredEntries.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">
              {searchTerm 
                ? `Aucun résultat trouvé pour "${searchTerm}"`
                : selectedLetter 
                  ? `Aucun mot commençant par la lettre "${selectedLetter.toUpperCase()}"`
                  : "Aucun mot trouvé dans le dictionnaire."
              }
            </p>
          </div>
        ) : (
          <>
            <p className="text-sm text-gray-500 mb-4 text-center">
              {filteredEntries.length} mot{filteredEntries.length > 1 ? 's' : ''} trouvé{filteredEntries.length > 1 ? 's' : ''}
            </p>
            {filteredEntries.map((entry) => (
              <DictionaryEntry
                key={entry.id}
                tamazightWord={entry.tamazightWord}
                latinTranscription={entry.latinTranscription}
                frenchTranslation={entry.frenchTranslation}
                englishTranslation={entry.englishTranslation}
                pronunciation={entry.pronunciation}
                example={entry.example}
              />
            ))}
          </>
        )}
      </div>
    </div>
  );
};

export default DictionaryPage;
