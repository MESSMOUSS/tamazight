import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen } from "lucide-react";

interface LessonCardProps {
  title: string;
  description: string;
  level: string;
  duration: string;
  onClick: () => void;
}

const LessonCard = ({ title, description, level, duration, onClick }: LessonCardProps) => {
  return (
    <Card className="h-full flex flex-col overflow-hidden border-2 hover:border-tamazight-blue transition-all duration-300 hover:shadow-md">
      <CardHeader className="bg-gradient-to-r from-tamazight-blue to-tamazight-green text-white">
        <CardTitle>{title}</CardTitle>
        <CardDescription className="text-tamazight-cream">{description}</CardDescription>
      </CardHeader>
      <CardContent className="py-4 flex-grow">
        <div className="flex justify-between text-sm text-muted-foreground mb-2">
          <span className="bg-tamazight-blue/10 px-2 py-1 rounded-full text-tamazight-blue">Niveau: {level}</span>
          <span className="bg-tamazight-green/10 px-2 py-1 rounded-full text-tamazight-green">Durée: {duration}</span>
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        <Button onClick={onClick} className="w-full bg-tamazight-orange hover:bg-tamazight-yellow text-white transform transition-transform duration-300 hover:scale-105">
          <BookOpen className="mr-2 h-4 w-4" />
          Démarrer la leçon
        </Button>
      </CardFooter>
    </Card>
  );
};

export default LessonCard;
