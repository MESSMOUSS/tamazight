import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Send, User, Bot } from "lucide-react";

interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  correction?: string;
}

const ConversationSimulator = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Azul! Amek telliḍ?",
      sender: "bot",
    },
  ]);
  const [input, setInput] = useState("");

  // Simulation de réponses du bot
  const botResponses: Record<string, string> = {
    "azul": "Azul! Amek telliḍ ass-a?",
    "amek": "Labaṣ, tanemmirt. I kečč/kemm?",
    "labas": "Yelha! D acu i tebɣiḍ ad tissineḍ?",
    "tanemmirt": "Ulac aɣilif!",
    "hi": "Azul! Amek telliḍ? (Bonjour! Comment vas-tu?)",
    "bonjour": "Azul! Amek telliḍ ass-a? (Bonjour! Comment vas-tu aujourd'hui?)"
  };

  // Simulation de corrections (dans une vraie application, cela serait basé sur un algo plus complexe)
  const correctMessage = (text: string): string | undefined => {
    const lowerText = text.toLowerCase();
    
    // Exemples de corrections simples
    if (lowerText === "azol") return "azul";
    if (lowerText === "tenmirt") return "tanemmirt";
    if (lowerText === "amek telit") return "amek telliḍ";
    
    return undefined;
  };

  const handleSendMessage = () => {
    if (!input.trim()) return;
    
    // Ajouter le message de l'utilisateur
    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: "user",
    };
    
    // Vérifier s'il y a une correction à apporter
    const correction = correctMessage(input);
    if (correction) {
      userMessage.correction = correction;
    }
    
    setMessages([...messages, userMessage]);
    
    // Simuler une réponse du bot
    setTimeout(() => {
      let botResponse = "Je ne comprends pas encore cette phrase. Essayez autre chose!";
      
      // Recherche de mots clés pour simuler une compréhension
      const lowerInput = input.toLowerCase();
      
      for (const [keyword, response] of Object.entries(botResponses)) {
        if (lowerInput.includes(keyword.toLowerCase())) {
          botResponse = response;
          break;
        }
      }
      
      setMessages(prevMessages => [
        ...prevMessages,
        {
          id: Date.now().toString(),
          text: botResponse,
          sender: "bot",
        },
      ]);
    }, 1000);
    
    setInput("");
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Conversation en Tamazight</CardTitle>
      </CardHeader>
      <CardContent className="h-96 overflow-y-auto">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.sender === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`flex items-start max-w-[80%] ${
                  message.sender === "user"
                    ? "bg-tamazight-blue text-white"
                    : "bg-gray-100 text-gray-800"
                } p-3 rounded-lg`}
              >
                <div className="mr-2">
                  {message.sender === "user" ? 
                    <User className="h-5 w-5" /> : 
                    <Bot className="h-5 w-5" />
                  }
                </div>
                <div>
                  <p>{message.text}</p>
                  {message.correction && (
                    <p className="text-xs mt-1 text-tamazight-yellow">
                      Suggestion: {message.correction}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter>
        <div className="flex w-full items-center space-x-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Tapez votre message en tamazight ou en français..."
            onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
          />
          <Button 
            onClick={handleSendMessage} 
            className="bg-tamazight-green hover:bg-tamazight-blue"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default ConversationSimulator;
