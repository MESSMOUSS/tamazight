import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Book, Languages } from "lucide-react";
const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const navigateToSection = (sectionId: string) => {
    setIsMenuOpen(false);
    window.location.hash = sectionId;
  };
  return <header className="sticky top-0 z-50 w-full bg-tamazight-cream shadow-sm">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <span onClick={() => navigateToSection("home")} className="font-bold text-tamazight-blue cursor-pointer text-left mx-0 text-lg">
            TamazightTutor
          </span>
        </div>
        
        <div className="hidden md:flex md:items-center md:gap-6">
          <nav className="flex items-center gap-6">
            <button onClick={() => navigateToSection("home")} className="font-medium text-tamazight-blue hover:text-tamazight-green transition-colors">
              Accueil
            </button>
            <button onClick={() => navigateToSection("learn")} className="font-medium text-tamazight-blue hover:text-tamazight-green transition-colors">
              Apprendre
            </button>
            <button onClick={() => navigateToSection("practice")} className="font-medium text-tamazight-blue hover:text-tamazight-green transition-colors">
              Exercices
            </button>
            <button onClick={() => navigateToSection("dictionary")} className="font-medium text-tamazight-blue hover:text-tamazight-green transition-colors">
              Dictionnaire
            </button>
            <button onClick={() => navigateToSection("translation")} className="font-medium text-tamazight-blue hover:text-tamazight-green transition-colors">
              Traduction
            </button>
            <button onClick={() => navigateToSection("conversation")} className="font-medium text-tamazight-blue hover:text-tamazight-green transition-colors">
              Conversation
            </button>
          </nav>
          <Button className="bg-tamazight-blue hover:bg-tamazight-green" onClick={() => navigateToSection("learn")}>
            Commencer
          </Button>
        </div>

        <Button variant="ghost" size="icon" className="md:hidden" onClick={toggleMenu}>
          {isMenuOpen ? <X /> : <Menu />}
        </Button>
      </div>

      {isMenuOpen && <div className="container pb-4 md:hidden">
          <nav className="flex flex-col space-y-4">
            <button onClick={() => navigateToSection("home")} className="font-medium text-tamazight-blue">
              Accueil
            </button>
            <button onClick={() => navigateToSection("learn")} className="font-medium text-tamazight-blue">
              Apprendre
            </button>
            <button onClick={() => navigateToSection("practice")} className="font-medium text-tamazight-blue">
              Exercices
            </button>
            <button onClick={() => navigateToSection("dictionary")} className="font-medium text-tamazight-blue">
              Dictionnaire
            </button>
            <button onClick={() => navigateToSection("translation")} className="font-medium text-tamazight-blue">
              Traduction
            </button>
            <button onClick={() => navigateToSection("conversation")} className="font-medium text-tamazight-blue">
              Conversation
            </button>
            <Button className="bg-tamazight-blue hover:bg-tamazight-green w-full" onClick={() => navigateToSection("learn")}>
              Commencer
            </Button>
          </nav>
        </div>}
    </header>;
};
export default Header;
