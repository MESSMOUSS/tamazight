import { Heart, ArrowUp } from "lucide-react";
import { Button } from "@/components/ui/button";
const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };
  const currentYear = new Date().getFullYear();
  return <footer className="mt-auto py-6 bg-tamazight-blue text-white">
      <div className="container">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="text-sm text-center">
              © {currentYear} TamazightTutor - Plateforme d'apprentissage du Tamazight
            </p>
          </div>
          <div className="flex items-center text-sm">
            <span className="text-base text-left font-normal px-[7px] mx-0">Fait avec</span>
            <Heart className="h-4 w-4 text-tamazight-orange fill-tamazight-orange bg-sky-800 rounded-xl mx-[18px] my-[24px]" />
            <span>pour la préservation de la langue amazighe </span>
            <span className="text-4xl text-center font-extrabold mx-[29px]"> Powered by AOUDJ Massil</span>        
            
          </div>
        </div>
        <div className="mt-4 flex justify-center">
          <Button variant="outline" onClick={scrollToTop} className="hover:bg-tamazight-cream text-slate-400">
            <ArrowUp className="mr-2 h-4 w-4" />
            Retour en haut
          </Button>
        </div>
      </div>
    </footer>;
};
export default Footer;
