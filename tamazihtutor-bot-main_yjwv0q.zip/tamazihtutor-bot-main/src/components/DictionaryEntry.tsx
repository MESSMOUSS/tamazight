import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Volume2 } from "lucide-react";

interface DictionaryEntryProps {
  tamazightWord: string;
  latinTranscription: string;
  frenchTranslation: string;
  englishTranslation?: string;
  pronunciation: string;
  example: {
    tamazight: string;
    french: string;
  };
}

const DictionaryEntry = ({
  tamazightWord,
  latinTranscription,
  frenchTranslation,
  englishTranslation,
  pronunciation,
  example,
}: DictionaryEntryProps) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const playPronunciation = () => {
    // Cette fonction simule la lecture de la prononciation
    // Dans une version réelle, on utiliserait l'API Web Speech ou un fichier audio
    console.log(`Playing pronunciation: ${pronunciation}`);
    
    // Simulation avec l'API Web Speech (si disponible dans le navigateur)
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(pronunciation);
      utterance.lang = 'fr-FR'; // À défaut de tamazight, on utilise le français
      speechSynthesis.speak(utterance);
    }
  };

  return (
    <Card className="w-full mb-4 hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl flex items-center">
            <span className="mr-2">{tamazightWord}</span>
            <span className="text-sm text-muted-foreground">({latinTranscription})</span>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={playPronunciation}
              title="Écouter la prononciation"
              className="ml-2 text-tamazight-blue"
            >
              <Volume2 className="h-4 w-4" />
            </Button>
          </CardTitle>
          <Button 
            variant="link" 
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-tamazight-blue p-0 h-auto"
          >
            {isExpanded ? "Moins" : "Plus"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-1">
          <p className="font-medium">{frenchTranslation}</p>
          {englishTranslation && (
            <p className="text-sm text-muted-foreground">En: {englishTranslation}</p>
          )}
        </div>
        
        {isExpanded && (
          <div className="mt-4 pt-4 border-t">
            <div className="mb-2">
              <h4 className="text-sm font-semibold">Prononciation:</h4>
              <p className="text-sm text-muted-foreground">{pronunciation}</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold">Exemple:</h4>
              <p className="text-sm">{example.tamazight}</p>
              <p className="text-sm text-muted-foreground">{example.french}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DictionaryEntry;
