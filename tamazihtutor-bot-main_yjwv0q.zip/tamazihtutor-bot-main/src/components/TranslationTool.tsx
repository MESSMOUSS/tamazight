import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { dictionaryEntries } from "@/data/dictionary";
import { Languages, ArrowRightLeft, Copy } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

type Language = "tamazight" | "french" | "english";

const TranslationTool = () => {
  const [inputText, setInputText] = useState("");
  const [outputText, setOutputText] = useState("");
  const [sourceLanguage, setSourceLanguage] = useState<Language>("french");
  const [targetLanguage, setTargetLanguage] = useState<Language>("tamazight");
  const [translationMethod, setTranslationMethod] = useState<"word" | "sentence">("word");
  const { toast } = useToast();

  const translateText = () => {
    if (!inputText.trim()) {
      toast({
        title: "Texte vide",
        description: "Veuillez entrer du texte à traduire",
        variant: "destructive",
      });
      return;
    }

    if (translationMethod === "word") {
      const words = inputText.toLowerCase().trim().split(/\s+/);
      const translatedWords = words.map(word => {
        const entry = dictionaryEntries.find(entry => {
          if (sourceLanguage === "tamazight") {
            return entry.latinTranscription.toLowerCase() === word || 
                  entry.tamazightWord.toLowerCase() === word;
          } else if (sourceLanguage === "french") {
            return entry.frenchTranslation.toLowerCase().includes(word);
          } else if (sourceLanguage === "english") {
            return entry.englishTranslation?.toLowerCase().includes(word);
          }
          return false;
        });

        if (entry) {
          if (targetLanguage === "tamazight") {
            return entry.tamazightWord;
          } else if (targetLanguage === "french") {
            return entry.frenchTranslation;
          } else if (targetLanguage === "english") {
            return entry.englishTranslation || "[traduction manquante]";
          }
        }
        
        return `[${word}]`; // Mot non trouvé
      });

      setOutputText(translatedWords.join(" "));
    } else {
      // Pour la traduction de phrases, approche simplifiée
      toast({
        title: "Traduction de phrase",
        description: "La traduction de phrases complètes est limitée au dictionnaire disponible",
      });
      
      // Tentative simple de traduction mot à mot
      const words = inputText.toLowerCase().trim().split(/\s+/);
      const translatedWords = words.map(word => {
        const entry = dictionaryEntries.find(entry => {
          if (sourceLanguage === "tamazight") {
            return entry.latinTranscription.toLowerCase() === word || 
                  entry.tamazightWord.toLowerCase() === word;
          } else if (sourceLanguage === "french") {
            return entry.frenchTranslation.toLowerCase() === word;
          } else if (sourceLanguage === "english") {
            return entry.englishTranslation?.toLowerCase() === word;
          }
          return false;
        });

        if (entry) {
          if (targetLanguage === "tamazight") {
            return entry.latinTranscription;
          } else if (targetLanguage === "french") {
            return entry.frenchTranslation;
          } else if (targetLanguage === "english") {
            return entry.englishTranslation || "[traduction manquante]";
          }
        }
        
        return word; // Garde le mot original si non trouvé
      });

      setOutputText(translatedWords.join(" "));
    }
  };

  const swapLanguages = () => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
    setInputText(outputText);
    setOutputText(inputText);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(outputText);
    toast({
      title: "Copié !",
      description: "Le texte a été copié dans le presse-papier",
    });
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Languages className="mr-2 h-5 w-5" />
          Outil de Traduction
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Tabs defaultValue="word" onValueChange={(value) => setTranslationMethod(value as "word" | "sentence")}>
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="word">Mot à mot</TabsTrigger>
              <TabsTrigger value="sentence">Phrase</TabsTrigger>
            </TabsList>
          </Tabs>
          
          <div className="flex items-center justify-between mb-4">
            <div className="w-5/12">
              <Select value={sourceLanguage} onValueChange={(value) => setSourceLanguage(value as Language)}>
                <SelectTrigger>
                  <SelectValue placeholder="Langue source" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tamazight">Tamazight</SelectItem>
                  <SelectItem value="french">Français</SelectItem>
                  <SelectItem value="english">Anglais</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button variant="ghost" size="icon" onClick={swapLanguages}>
              <ArrowRightLeft className="h-4 w-4" />
            </Button>
            
            <div className="w-5/12">
              <Select value={targetLanguage} onValueChange={(value) => setTargetLanguage(value as Language)}>
                <SelectTrigger>
                  <SelectValue placeholder="Langue cible" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tamazight">Tamazight</SelectItem>
                  <SelectItem value="french">Français</SelectItem>
                  <SelectItem value="english">Anglais</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-3">
            <Textarea
              placeholder="Entrez le texte à traduire..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="min-h-[100px]"
            />
            
            <Button onClick={translateText} className="w-full bg-tamazight-blue hover:bg-tamazight-green">
              Traduire
            </Button>
            
            <div className="relative">
              <Textarea
                placeholder="Traduction..."
                value={outputText}
                readOnly
                className="min-h-[100px]"
              />
              
              {outputText && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={copyToClipboard}
                  className="absolute top-2 right-2"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TranslationTool;
