import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

interface Choice {
  id: string;
  text: string;
}

interface QuizCardProps {
  question: string;
  choices: Choice[];
  correctAnswerId: string;
  explanation: string;
  onComplete: (isCorrect: boolean) => void;
}

const QuizCard = ({ question, choices, correctAnswerId, explanation, onComplete }: QuizCardProps) => {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const { toast } = useToast();

  const isCorrect = selectedAnswer === correctAnswerId;

  const handleSubmit = () => {
    if (!selectedAnswer) {
      toast({
        title: "Aucune réponse sélectionnée",
        description: "Veuillez choisir une réponse avant de soumettre.",
        variant: "destructive",
      });
      return;
    }

    setHasSubmitted(true);
    
    if (isCorrect) {
      toast({
        title: "Bonne réponse !",
        description: explanation,
        variant: "default",
      });
    } else {
      toast({
        title: "Réponse incorrecte",
        description: explanation,
        variant: "destructive",
      });
    }

    onComplete(isCorrect);
  };

  const handleNext = () => {
    setSelectedAnswer(null);
    setHasSubmitted(false);
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-xl">{question}</CardTitle>
        <CardDescription>Choisissez la bonne réponse</CardDescription>
      </CardHeader>
      <CardContent>
        <RadioGroup value={selectedAnswer || ""} onValueChange={setSelectedAnswer} className="space-y-3">
          {choices.map((choice) => (
            <div key={choice.id} className="flex items-center space-x-2">
              <RadioGroupItem value={choice.id} id={choice.id} disabled={hasSubmitted} />
              <Label htmlFor={choice.id} className="flex-grow cursor-pointer py-2">
                {choice.text}
              </Label>
              {hasSubmitted && choice.id === correctAnswerId && (
                <CheckCircle className="h-5 w-5 text-green-500" />
              )}
              {hasSubmitted && choice.id === selectedAnswer && choice.id !== correctAnswerId && (
                <XCircle className="h-5 w-5 text-red-500" />
              )}
            </div>
          ))}
        </RadioGroup>
      </CardContent>
      <CardFooter>
        {!hasSubmitted ? (
          <Button onClick={handleSubmit} className="w-full bg-tamazight-green hover:bg-tamazight-blue">
            Vérifier
          </Button>
        ) : (
          <Button onClick={handleNext} className="w-full bg-tamazight-blue hover:bg-tamazight-green">
            Continuer
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default QuizCard;
